# Mirrored Hallownest

Made by [Mimijackz#3527](github.com/mimijackz)

A mod for the game Hollow Knight.
Flips the entire Hollow Knight Map.
Inspired by the HollowTwitch mod by Sid003

This includes:
- The design
- The npcs
- The controls
- The transitions

This does NOT include, but hopefully will in later updates:
- the minimap
- the sounds